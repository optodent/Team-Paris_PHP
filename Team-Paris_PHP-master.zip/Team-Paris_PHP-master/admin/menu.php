<div class="panel panel-default menu">
    <div class="panel-heading">
        <h3 class="panel-title">Admin Panel</h3>
    </div>
    <div class="panel-body">
        <ul class="nav nav-pills nav-stacked" id="adminmenu">
            <li role="presentation" class="opts"><a href='index.php'>Blog</a></li>
            <li role="presentation" class="opts"><a href='users.php'>Users</a></li>
            <li role="presentation" class="opts"><a href="../" target="_blank">View Website</a></li>
            <li role="presentation" class="opts">
                <a href='logout.php'>Logout <span class="glyphicon glyphicon-log-out"></span></a>
            </li>
        </ul>
    </div>
</div>
<div class='clear'></div>