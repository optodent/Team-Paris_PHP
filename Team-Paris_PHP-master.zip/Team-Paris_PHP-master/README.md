Team-Paris_PHP
==============
Todo
1. View all posts  done
2. Adding new posts by owner done
3. Adding comments by visitor done
4. List of posts
5. Count visists done
6. Search by tags done
7. Database done
8. User registration done
9. Admin panel done